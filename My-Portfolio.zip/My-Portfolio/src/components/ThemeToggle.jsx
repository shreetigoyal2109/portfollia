import { useEffect } from 'react';

const ThemeToggle = () => {
  useEffect(() => {
    document.documentElement.classList.add('dark'); // Always apply dark mode
    localStorage.setItem('theme', 'dark');
  }, []);

  return null; // No button needed if dark mode is default and toggle is removed
};

export default ThemeToggle;