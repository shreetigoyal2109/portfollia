import About from "./components/About";
import Contact from "./components/Contact";
import Experience from "./components/Experience";
import HeroSection from "./components/HeroSection";
import Navbar from "./components/Navbar";
import Projects from "./components/Projects";
import TechnicalSkills from "./components/TechnicalSkills";
import Value from "./components/Value";
import { ThemeProvider } from "./context/ThemeContext";
const App = () => {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364] text-white">
        <Navbar />
        <div>
          <HeroSection />
          <About />
          <Projects />
          <Experience />
          <TechnicalSkills />
          <Value />
          <Contact />
        </div>
      </div>
    </ThemeProvider>
  );
};

export default App;